function f = EvaluateIndividual(x)
    g = EvaluateFunction(x);
    f = 1 / g;
end
