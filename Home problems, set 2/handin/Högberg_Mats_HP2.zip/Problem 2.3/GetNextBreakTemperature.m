function nextBreakTemperature = GetNextBreakTemperature(ambientBreakTemperature, deltaBreakTemperature)
    nextBreakTemperature = ambientBreakTemperature + deltaBreakTemperature;
end
