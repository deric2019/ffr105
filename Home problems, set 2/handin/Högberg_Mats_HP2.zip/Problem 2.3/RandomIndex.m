function index = RandomIndex(maxIndex)
    index = 1 + fix(rand * maxIndex);
end
