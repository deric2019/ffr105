function nextBrakeTemperature = GetNextBrakeTemperature(ambientBrakeTemperature, deltaBrakeTemperature)
    nextBrakeTemperature = ambientBrakeTemperature + deltaBrakeTemperature;
end
