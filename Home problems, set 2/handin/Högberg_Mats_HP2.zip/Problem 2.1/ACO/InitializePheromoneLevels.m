function pheromoneLevels = InitializePheromoneLevels(numberOfNodes, tau0)
    pheromoneLevels = ones(numberOfNodes) * tau0;
end
